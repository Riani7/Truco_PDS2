#ifndef JOG_PDS2
#define JOG_PDS2

#include <vector>
#include "carta.h"
#include <iostream>

using namespace std;

class jogador{
private:
bool _truco;
  vector<Carta *> _mao;
  unsigned _nmr;
public:
  jogador(unsigned nmr);
  void imprime_mao(); //imprime a mao do jogador
  bool pede_truco(); // gera um pedido de truco
  Carta joga_carta(); // retorna a carta escolhida pelo jogador
  int aumenta(); // retorna o novo valor da rodada
  void distribui();
  void coloca_carta(Carta *c);
  Carta * retira_carta(int indice);
  int get_quant_cartas();
};
#endif