#include "carta.h"
#include <iostream>
/*
Construtor: Recebe a pontuação da carta e e atribui o seu devido valor e naipe.
*/
Carta::Carta(int ponto){
  _ponto = ponto;
  _manilha = 0;
  if(_ponto == 1){
    _valor = '4';
    _naipe = ESPADA;
  }
  else if(_ponto == 2){
    _valor = '4';
    _naipe = COPAS;
  }
  else if(_ponto == 3){
    _valor = '4';
    _naipe = OURO;
  }
  else if(_ponto == 4){
    _valor = '5';
    _naipe = PAUS;
  }
  else if(_ponto == 5){
    _valor = '5';
    _naipe = ESPADA;
  }
  else if(_ponto == 6){
    _valor = '5';
    _naipe = COPAS;
  } 
  else if(_ponto == 7){
    _valor = '5';
    _naipe = OURO;
  }
  else if(_ponto == 8){
    _valor = '6';
    _naipe = PAUS;
  }
  else if(_ponto == 9){
    _valor = '6';
    _naipe = ESPADA;
  }
  else if(_ponto == 10){
    _valor = '6';
    _naipe = COPAS;
  }
  else if(_ponto == 11){
    _valor = '6';
    _naipe = OURO;
  }
  else if(_ponto == 12){
    _valor = '7';
    _naipe = PAUS;
  }
  else if(_ponto == 13){
    _valor = '7';
    _naipe = PAUS;
  }
  else if(_ponto == 14){
    _valor = 'Q';
    _naipe = PAUS;
  }
  else if(_ponto == 15){
    _valor = 'Q';
    _naipe = ESPADA;
  }
  else if(_ponto == 16){
    _valor = 'Q';
    _naipe = COPAS;
  }
  else if(_ponto == 17){
    _valor = 'Q';
    _naipe = OURO;
  }
  else if(_ponto == 18){
    _valor = 'J';
    _naipe = PAUS;
  }
  else if(_ponto == 19){
    _valor = 'J';
    _naipe = ESPADA;
  }
  else if(_ponto == 20){
    _valor = 'J';
    _naipe = COPAS;
  }
  else if(_ponto == 21){
    _valor = 'J';
    _naipe = OURO;
  }
    else if(_ponto == 22){
    _valor = 'K';
    _naipe = PAUS;
  }
  else if(_ponto == 23){
    _valor = 'K';
    _naipe = ESPADA;
  }
  else if(_ponto == 24){
    _valor = 'K';
    _naipe = COPAS;
  }
  else if(_ponto == 25){
    _valor = 'K';
    _naipe = OURO;
  }
      else if(_ponto == 26){
    _valor = 'A';
    _naipe = PAUS;
  }
  else if(_ponto == 27){
    _valor = 'A';
    _naipe = COPAS;
  }
  else if(_ponto == 28){
    _valor = 'A';
    _naipe = OURO;
  }
    else if(_ponto == 29){
    _valor = '2';
    _naipe = PAUS;
  }
  else if(_ponto == 30){
    _valor = '2';
    _naipe = ESPADA;
  }
  else if(_ponto == 31){
    _valor = '2';
    _naipe = COPAS;
  }
  else if(_ponto == 32){
    _valor = '2';
    _naipe = OURO;
  }
    else if(_ponto == 33){
    _valor = '3';
    _naipe = PAUS;
  }
  else if(_ponto == 34){
    _valor = '3';
    _naipe = ESPADA;
  }
  else if(_ponto == 35){
    _valor = '3';
    _naipe = COPAS;
  }
  else if(_ponto == 36){
    _valor = '3';
    _naipe = OURO;
  }
    else if(_ponto == 37){
    _valor = '7';
    _naipe = OURO;
    _manilha =1;
  }
  else if(_ponto == 38){
    _valor = 'A';
    _naipe = ESPADA;
    _manilha =1;
  }
  else if(_ponto == 39){
    _valor = '7';
    _naipe = COPAS;
    _manilha =1;
  }
  else if(_ponto == 40){
    _valor = '4';
    _naipe = PAUS;
    _manilha =1;
  }
}

void Carta::imprime_carta(){
  std::string n;
  if(_naipe == ESPADA){
    n="Espada";
  }
  else if(_naipe == COPAS){
    n="Copas";
  }
  else if(_naipe == OURO){
    n="Ouros";
  }
  else{
    n="Paus";
  }
  std::cout<<_valor<<" de "<<n<<" ";
}

naipe Carta::get_naipe(){
  return _naipe;
};

char Carta::get_valor(){
  return _valor;
};

int Carta::get_ponto(){
  return _ponto;
};