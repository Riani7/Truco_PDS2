#ifndef CARTA_PDS2
#define CARTA_PDS2

#include <iostream>
#include <string.h>

using namespace std;

enum naipe{
  ESPADA = 'E',
  COPAS = 'C',
  OURO = 'O',// so pode ser char
  PAUS = 'P'
};

class Carta {
private:
  naipe _naipe;
  char _valor;
  int _ponto;
  bool _manilha;
public:
  Carta(int ponto);//construtor
  naipe get_naipe();
  string get_nome();
  char get_valor();
  int get_ponto();
  void imprime_carta();
  
};

#endif