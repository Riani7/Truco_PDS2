#include<iostream>
#include "jogo.h"
#include "jogador.h"

jogo::jogo(){
  _queda=0;
  _queda_bot=0;
  _mao=0;
  _mao_bot=0;
  _rodada=0;
  _rodada_bot=0;
}

void jogo::imprime_msg_jog1_ou_jog2(int da_vez){
  cout<<endl<<"Vez do jogador "<<da_vez<<endl;
  cout<<endl<<"Selecione uma carta: ";
}

void jogo::imprime_comeco(){
  cout<<"BEM-VINDO AO TRUCO"<<endl
    <<"aperte 1 para comecar"<<endl;
}
void jogo::imprime_mesa(Carta *c){
  cout<<"MESA: ";
  c->imprime_carta();
  cout<<endl;
}
void jogo::imprime_mesa_vazia(){
  cout<<"MESA: -"<<endl;
}
bool jogo::imprime_placar(){

  if(_queda>=12){
    _mao++;
    _queda=0;
    _queda_bot=0;
  }
  else if(_queda_bot>=12){
    _mao_bot++;
    _queda=0;
    _queda_bot=0;
  }
  if(_mao>=2 || _mao_bot>=2){
    cout<<"Fim de jogo"<<endl;
  }
  
  cout<<"PLACAR:   queda:"<< _queda
  <<"x"<< _queda_bot<<" mao:"<< _mao<<"x"
  << _mao_bot<<" rodada:"<< _rodada<<"x"
  << _rodada_bot<<endl; 

  if(_mao>=2)
    return false;
  else if(_mao_bot>=2)
    return false;
  else
    return true;
}
void jogo::imprime_vez(){
  cout<<"Sua vez, jogue uma carta (selecione 1, 2 ou 3)"<<endl;
}
bool jogo::imprime_ganhou_rodada(int g, int valor){
  if(g==1){
    cout<<"Jogador 1 levou!!"<<endl;
    _rodada++;
    if(_rodada==2){
      _rodada=0;
      _rodada_bot=0;
      _queda+=valor;
      return false;
    }
    return true;
  }
  else{
    cout<<"Jogador 2 levou!!"<<endl;
    _rodada_bot++;
    if(_rodada_bot ==2){
      _rodada_bot = 0;
      _rodada = 0;
      _queda_bot +=valor;
      return false;
    }
  }
  return true;
}

void jogo::cria_baralho(){
  for(int i=0;i<40;i++){
    baralho.push_back(new Carta(i));
  }
}

void jogo::termina_jogo(){
  for(int i=0;i<40;i++){
  //baralho.push_back(delete baralho[i]);
}
}

void jogo::jogada(Carta *c){
  baralho.push_back(c);
}
int jogo::compara_cartas(Carta *c1, Carta *c2){
  int ganhador = 0;
  if(c1->get_ponto()>c2->get_ponto()){
    ganhador = 1;
  }
  else{
    ganhador = 2;
  }
  return ganhador;
}