#ifndef JOGO_PDS2
#define JOGO_PDS2

#include "carta.h"
#include "jogador.h"

class jogo{
private:
  int _queda;
  int _queda_bot;
  int _mao;
  int _mao_bot;
  int _rodada;
  int _rodada_bot;
  vector<Carta *> baralho;
public:
jogo();//construtor feito
void imprime_mesa(Carta *c);//+-feito
void imprime_mesa_vazia();
void imprime_msg_jog1_ou_jog2(int da_vez);
bool imprime_placar();//feito
void imprime_vez();//feito
void imprime_jogada(Carta c);
bool imprime_ganhou_rodada(int g, int valor);//feito
void imprime_comeco();//feito
void cria_baralho();
void termina_jogo();
void jogada(Carta *c);
int compara_cartas(Carta *c1, Carta *c2);
};
#endif