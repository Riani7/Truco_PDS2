
#include "jogador.h"
#include <cstdlib>
#include <iostream>


jogador::jogador(unsigned nmr){
  _nmr = nmr;
  _truco = 0;
}
/*
Carta jogador::joga_carta(){
  
}
*/
void jogador::coloca_carta(Carta *c){
  _mao.push_back(c);
}

void jogador::imprime_mao(){
  std::cout<<std::endl<<"Mão do jogador "<<_nmr<<":";
  for(int i=0; i<_mao.size(); i++){
    std:: cout<<endl<<"("<<i+1<<") ";
    _mao[i]->imprime_carta();
  }
  std::cout<<endl;
}

Carta *jogador::retira_carta(int i){
  Carta *retorno;
  retorno = _mao[i];
  _mao.erase(_mao.begin()+i);
  return retorno;
}

int jogador::get_quant_cartas(){
  return _mao.size();
}
