#include <iostream>
#include <ctime>
#include <vector>
#include "jogo.h"
#include "carta.h"
#include <time.h>
#include <stdlib.h>

int main() {
int comecou =0;
jogo *j = new jogo();
j->imprime_comeco();
while(comecou!=1){
  cin>>comecou;
}
bool embaralhar_outra_rodada = true;
while(embaralhar_outra_rodada){
//criando baralho
vector<Carta *> baralho;
for(int i=0;i<40;i++){
  baralho.push_back(new Carta(i));
}
//criando jogadores
jogador *jog = new jogador(1);
jogador *jog2 = new jogador(2);
//iniciar jogo
j->imprime_placar();
j->imprime_mesa_vazia();
//distribuindo cartas
  while(jog->get_quant_cartas()>0)
    jog->retira_carta(0);
  while(jog2->get_quant_cartas()>0)
    jog2->retira_carta(0);
  int carta1_j1=0, carta2_j1=0,     
  carta3_j1=0,carta1_j2=0,carta2_j2=0,carta3_j2=0;
  carta1_j1= rand()%40;
  carta2_j1 = rand()%40;
  carta3_j1 = rand()%40;
  jog->coloca_carta(baralho[carta1_j1]);
  jog->coloca_carta(baralho[carta2_j1]);
  jog->coloca_carta(baralho[carta3_j1]);
  carta1_j2 = rand()%40;
  carta2_j2 = rand()%40;
  carta3_j2 = rand()%40;
  jog2->coloca_carta(baralho[carta1_j2]);
  jog2->coloca_carta(baralho[carta2_j2]);
  jog2->coloca_carta(baralho[carta3_j2]);
  //jogador 1 joga
  int jogada =0;
  int da_vez=1;
  int ganhador = 0;
  bool jogo =true;//por hora jogo=2 p simular uma rodada
  int controle = 0;
    Carta *carta_mesa;
    Carta *carta_mesa_2;
   // jog->imprime_mao();
   // jog2->imprime_mao();
  while(jogo){
    j->imprime_msg_jog1_ou_jog2(da_vez); // imprime msg antes da jogada
    if(da_vez==1){
      jog->imprime_mao();
      }
    else if(da_vez==2){
      jog2->imprime_mao();
    }
    cin>>jogada;
    while((jogada>jog->get_quant_cartas() && da_vez==1) ||
          (jogada>jog2->get_quant_cartas() && da_vez==2)){
      cout<<endl<<"Jogada inválida."<<endl;
      j->imprime_msg_jog1_ou_jog2(da_vez);
      cin>>jogada;
    }
    if(da_vez==1){
      carta_mesa = jog->retira_carta(jogada-1); //tira a carta da mao. Essa função retorna uma carta que será colocada na mesa
      da_vez++; //passa a vez
      controle++;
      j->imprime_mesa(carta_mesa);
      //jog->imprime_mao();
      }
    else if(da_vez==2){
      carta_mesa_2 = jog2->retira_carta(jogada-1);
      da_vez--;
      controle++;
      j->imprime_mesa(carta_mesa_2);
      //jog2->imprime_mao();
    }
    //comparar cartas
    if(controle ==2){
      ganhador = j->compara_cartas(carta_mesa, carta_mesa_2);
      jogo = j->imprime_ganhou_rodada(ganhador, 2);
      embaralhar_outra_rodada = j->imprime_placar();
      controle=0;
    }
  }
  delete jog;
delete jog2;
}


delete j;
//deletar baralho
return 0;
}